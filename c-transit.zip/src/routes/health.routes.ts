import healthRouter from "../controller/health.controller.js";

export default healthRouter;
