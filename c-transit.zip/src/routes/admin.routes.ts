import adminRouter from "../controller/admin.controller.js";

export default adminRouter;
